# UAS_SC
UAS sistem cerdas  bikin bot tentang X dan Y yang sudah di normalisasi 
